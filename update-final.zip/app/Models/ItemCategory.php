<?php

namespace App\Models;

/**
 * ItemCategory Model Alias
 * 
 * Provides compatibility for controllers importing from App\Models
 */
class ItemCategory extends \App\Modules\Requisitions\Models\ItemCategory
{
}
