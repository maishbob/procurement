<?php

namespace App\Models;

/**
 * PurchaseOrder Model Alias
 * 
 * Provides compatibility for controllers importing from App\Models
 */
class PurchaseOrder extends \App\Modules\PurchaseOrders\Models\PurchaseOrder
{
}
