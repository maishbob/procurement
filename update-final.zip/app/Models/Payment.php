<?php

namespace App\Models;

/**
 * Payment Model Alias
 * 
 * Provides compatibility for controllers importing from App\Models
 */
class Payment extends \App\Modules\Finance\Models\Payment
{
}
