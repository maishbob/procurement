<?php

namespace App\Models;

/**
 * Store Model Alias
 * Points to the actual model in the Inventory module
 */
class Store extends \App\Modules\Inventory\Models\Store
{
}
