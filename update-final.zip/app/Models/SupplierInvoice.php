<?php

namespace App\Models;

/**
 * SupplierInvoice Model Alias
 * 
 * Provides compatibility for controllers importing from App\Models
 */
class SupplierInvoice extends \App\Modules\Finance\Models\SupplierInvoice
{
}
