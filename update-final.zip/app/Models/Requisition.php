<?php

namespace App\Models;

/**
 * Requisition Model Alias
 * 
 * Provides compatibility for controllers importing from App\Models
 */
class Requisition extends \App\Modules\Requisitions\Models\Requisition
{
}
