<?php

namespace App\Models;

/**
 * Supplier Model Alias
 * 
 * Provides compatibility for controllers importing from App\Models
 */
class Supplier extends \App\Modules\Suppliers\Models\Supplier
{
}
