<?php

namespace App\Models;

/**
 * InventoryItem Model Alias
 * Points to the actual model in the Inventory module
 */
class InventoryItem extends \App\Modules\Inventory\Models\InventoryItem
{
}
